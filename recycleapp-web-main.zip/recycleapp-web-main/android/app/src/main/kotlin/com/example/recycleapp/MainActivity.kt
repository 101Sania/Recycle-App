package com.example.recycleapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
